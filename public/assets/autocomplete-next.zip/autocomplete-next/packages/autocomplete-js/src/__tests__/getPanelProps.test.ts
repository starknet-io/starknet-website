describe('getPanelProps', () => {
  test.todo('tests');
});
