describe('getEnvironmentProps', () => {
  test.todo('tests');
});
