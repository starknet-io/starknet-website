declare const __TEST__: boolean;
