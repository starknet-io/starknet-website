export interface AutocompleteContext {
  [key: string]: unknown;
}
