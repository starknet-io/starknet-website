export type Contributor = {
  login: string;
  org: string;
  avatar_url: string;
  id: number;
};
