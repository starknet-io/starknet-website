export type NotificationFilter = {
  token: string;
  value: string;
  attribute: string;
};
