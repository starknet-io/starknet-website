export type AutocompleteItem = {
  token: string;
  label: string;
  attribute: string;
};
