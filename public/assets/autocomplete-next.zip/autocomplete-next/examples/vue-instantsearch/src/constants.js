export const INSTANT_SEARCH_INDEX_NAME = 'instant_search';

export const INSTANT_SEARCH_HIERARCHICAL_ATTRIBUTE =
  'hierarchicalCategories.lvl0';
