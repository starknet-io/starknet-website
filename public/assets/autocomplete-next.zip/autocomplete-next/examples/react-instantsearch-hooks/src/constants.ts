export const INSTANT_SEARCH_INDEX_NAME = 'instant_search';
export const INSTANT_SEARCH_QUERY_SUGGESTIONS =
  'instant_search_demo_query_suggestions';
export const INSTANT_SEARCH_HIERARCHICAL_ATTRIBUTES = [
  'hierarchicalCategories.lvl0',
  'hierarchicalCategories.lvl1',
];
